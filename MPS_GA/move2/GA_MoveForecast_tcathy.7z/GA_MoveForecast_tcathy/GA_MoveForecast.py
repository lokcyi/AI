'''
目標: 分配FcstMove至各產品各站, 使FcstMove總和盡量與Excel之FcstMove總和接近(分別by Prod, by Mg計算總合)
須滿足以下條件:
rule1: 當站FcstMove<當站CloseWip+當站Wip  (計算於MOVE_UB)
rule2: 當站FcstMove<當站wip+前一站FcstMove  (計算於MOVE_UB2)
'''

import pygad # https://pypi.org/project/pygad/
import sys
import math
import pandas as pd
import numpy as np
import random
import datetime 

stime = datetime.datetime.now() 
population_size = 30
generation_index = 1
dfProdMoveTargetExcel = pd.read_excel(r"D:\Projects\MachineLearning\myHW3\GA_SAMPLEDATA2.xlsx",sheet_name="prod_target")
dfMgMoveTargetExcel = pd.read_excel(r"D:\Projects\MachineLearning\myHW3\GA_SAMPLEDATA2.xlsx",sheet_name="mg_target")
dfWipExcel = pd.read_excel(r"D:\Projects\MachineLearning\myHW3\GA_SAMPLEDATA2.xlsx",sheet_name="prod")

def get_prod_move_target():
    return dfProdMoveTargetExcel.reset_index()

def get_mg_move_target():
    return dfMgMoveTargetExcel.reset_index()

def get_wip():
    dfWip = dfWipExcel.reset_index()
    dfWip = dfWip.fillna(0)
    dfWip["MOVE_UB"] = dfWip["WIP"]+dfWip["CLOSE_WIP"] #wip upper bound by op (rule1)
    return dfWip

def get_op_max_move():
    dfWip = get_wip()
    ub1 = max(dfWip['MOVE_UB'])
    return ub1

def get_total_move():
    dfWip = dfWipExcel.reset_index()
    dfWip = dfWip.fillna(0)
    return sum(dfWip['MOVE'])

def getLowerMove(row):
    moveUb2 = row['MOVE_UB2']
    moveRandom = row['MOVE_RANDOM']
    if moveRandom <= moveUb2:
        return moveRandom
    else:
        return moveUb2
    
def getMoveByRule(row):
    moveUb = row['MOVE_UB']
    moveUb2 = row['MOVE_UB2']
    moveRandom = row['MOVE_RANDOM']
    if moveRandom <= moveUb and moveRandom <= moveUb2:
        return moveRandom
    else:
        if moveUb <= moveUb2:
            return moveUb
        else:
            return moveUb2
    
# 紀錄修正前後的染色體
def set_solution_map(sol, repaired_sol):
    sol_str = "".join(str(x) for x in sol) # 串接陣列內各元素
    if sol_str in solution_map:
        pass
    else:
        solution_map[sol_str] = repaired_sol

# 產生初始族群
#取0~wip+closeWip的亂數(by rule1)
def create_init_population():
    dfWip = get_wip()
    init_population = []
    for i in range(population_size):
        # 依照每站wip的上限(WIP+CLOSE_WIP)產生亂數作為move (基因)
        dfMove = dfWip.assign(MOVE_RANDOM = random.uniform(0,dfWip["MOVE_UB"]))
        dfMove = dfMove.assign(PRE_MOVE_RANDOM = 0.0)
        for idx in dfMove.index: 
            if idx>0:
                dfMove.loc[int(idx),'PRE_MOVE_RANDOM'] = dfMove.loc[int(idx)-1,'MOVE_RANDOM']
    
        dfMove.loc[0,'PRE_MOVE_RANDOM'] = 100.0
        dfMove.loc[10,'PRE_MOVE_RANDOM'] = 50.0
        dfMove.loc[17,'PRE_MOVE_RANDOM'] = 0.0
        dfMove.loc[26,'PRE_MOVE_RANDOM'] = 100.0
        
        dfMove = dfMove.assign(MOVE_UB2 = dfMove['WIP'] + dfMove['PRE_MOVE_RANDOM'])
        
        #修正MOVE_RANDOM以滿足rule2
        dfMove = dfMove.assign(MOVE_RANDOM2 = dfMove["MOVE_RANDOM"])
        for idx in dfMove.index: 
            if idx < dfMove.shape[0]:
                if dfMove.loc[int(idx),'MOVE_RANDOM'] > dfMove.loc[int(idx),'MOVE_UB2']:
                    dfMove.loc[int(idx),'MOVE_RANDOM2'] = dfMove.loc[int(idx),'MOVE_UB2']
                    dfMove.loc[int(idx+1),'PRE_MOVE_RANDOM'] = dfMove.loc[int(idx),'MOVE_UB2']
                    dfMove.loc[int(idx+1),'MOVE_UB2'] = dfMove.loc[int(idx+1),'WIP'] + dfMove.loc[int(idx+1),'PRE_MOVE_RANDOM']
                    
        #print(dfMove)

        random_num = list(dfMove["MOVE_RANDOM2"])
        random_num_int = np.floor(random_num)
        init_population.append(random_num_int)
    return init_population

#經過交配及突變之後的染色體, 需再修正以滿足rule1及rule2, 且基因須修正為INT
def get_new_move(solution):
    dfWip = get_wip()
    dfSol = pd.DataFrame({'MOVE_RANDOM':solution})
    dfMove = pd.concat([dfWip, dfSol.reindex(dfWip.index)], axis=1)
    
    dfMove = dfMove.assign(PRE_MOVE_RANDOM = 0.0)
    for idx in dfMove.index: 
        if idx > 0:
            dfMove.loc[int(idx),'PRE_MOVE_RANDOM'] = dfMove.loc[int(idx)-1,'MOVE_RANDOM']
    
    dfMove.loc[0,'PRE_MOVE_RANDOM'] = 100.0
    dfMove.loc[10,'PRE_MOVE_RANDOM'] = 50.0
    dfMove.loc[17,'PRE_MOVE_RANDOM'] = 0.0
    dfMove.loc[26,'PRE_MOVE_RANDOM'] = 100.0
    dfMove = dfMove.assign(MOVE_UB2 = dfMove['WIP'] + dfMove['PRE_MOVE_RANDOM'])
    
    dfMove = dfMove.assign(MOVE_RANDOM2 = dfMove["MOVE_RANDOM"])
    for idx in dfMove.index: 
        if idx < dfMove.shape[0]:
            if dfMove.loc[int(idx),'MOVE_RANDOM'] > dfMove.loc[int(idx),'MOVE_UB'] or dfMove.loc[int(idx),'MOVE_RANDOM'] > dfMove.loc[int(idx),'MOVE_UB2']:
                if dfMove.loc[int(idx),'MOVE_UB'] <= dfMove.loc[int(idx),'MOVE_UB2']:
                    dfMove.loc[int(idx),'MOVE_RANDOM2'] = dfMove.loc[int(idx),'MOVE_UB']
                    dfMove.loc[int(idx+1),'PRE_MOVE_RANDOM'] = dfMove.loc[int(idx),'MOVE_RANDOM2']
                    dfMove.loc[int(idx+1),'MOVE_UB2'] = dfMove.loc[int(idx+1),'WIP'] + dfMove.loc[int(idx+1),'PRE_MOVE_RANDOM']
                else:
                    dfMove.loc[int(idx),'MOVE_RANDOM2'] = dfMove.loc[int(idx),'MOVE_UB2']
                    dfMove.loc[int(idx+1),'PRE_MOVE_RANDOM'] = dfMove.loc[int(idx),'MOVE_UB2']
                    dfMove.loc[int(idx+1),'MOVE_UB2'] = dfMove.loc[int(idx+1),'WIP'] + dfMove.loc[int(idx+1),'PRE_MOVE_RANDOM']
    
    repaired_sol = list(dfMove["MOVE_RANDOM2"])
    repaired_sol_int = np.floor(repaired_sol)
    return dfMove, repaired_sol_int 

# 適合度函數
# abs(每個產品MOVE總和-產品TARGET)平均值越小
# abs(每個機台群MOVE總和-機台群TARGET)平均值越小
# 取兩項相加最小
def fitness_func(solution, solution_idx):

    #經過交配及突變之後的染色體, 需再修正以滿足rule1及rule2
    dfMove, solution_fix = get_new_move(solution)
    
    dfProdMoveTarget = get_prod_move_target()
    dfMgMoveTarget = get_mg_move_target()

    # by Prod
    dfProdMoveRandom = dfMove.groupby(['PROD'])['MOVE_RANDOM2'].sum().reset_index()
    dfProdMove = pd.concat([dfProdMoveRandom, dfProdMoveTarget.reindex(dfProdMoveRandom.index)], axis=1)
    dfProdMove = dfProdMove.assign(MAE = abs(dfProdMove['MOVE_RANDOM2']-dfProdMove['FCST_MOVE']))
    prodMoveMAE = sum(dfProdMove['MAE'])/dfProdMove.shape[0]

    # by Mg
    dfMgMoveRandom = dfMove.groupby(['TOOLG'])['MOVE_RANDOM2'].sum().reset_index()
    dfMgMove = pd.concat([dfMgMoveRandom, dfMgMoveTarget.reindex(dfMgMoveRandom.index)], axis=1)
    dfMgMove = dfMgMove.assign(MAE = abs(dfMgMove['MOVE_RANDOM2']-dfMgMove['FCST_MOVE']))
    mgMoveMAE = sum(dfMgMove['MAE'])/dfMgMove.shape[0]
    
    if prodMoveMAE == 0 and mgMoveMAE == 0:
        fitnessVal = 1
    else:    
        fitnessVal = 1 / (prodMoveMAE + mgMoveMAE)
    
    global generation_index
    generation_index += 1
    print(str(generation_index//30) + "-" + str(solution_idx) + ", " + str(prodMoveMAE + mgMoveMAE))
    dfMoveShow = dfMove[['WIP','PRE_MOVE_RANDOM','MOVE_UB2','MOVE_UB','MOVE_RANDOM2']]
    #print(dfMoveShow)
    set_solution_map(solution, solution_fix)
    return fitnessVal # 目標: 差距最小

population_list = create_init_population()
mutation_max_val = get_op_max_move()
solution_map = {} # key: source solution, value: repaired solution
fitness_map = {}


# 建立 GA 實體
ga_instance = pygad.GA(
                       # 產生初始族群
                       initial_population = population_list,

                       # 選擇 (selection)
                       parent_selection_type = "rws", # 選擇方式
                       keep_parents = 2,

                       # 交配 (crossover)
                       num_parents_mating = population_size, # 取幾個個體進行交配                    
                       crossover_probability = 0.8, # 交配機率
                       crossover_type = "two_points", # 交配方式

                       # 突變 (mutation)
                       mutation_probability = 0.2, # 突變機率
                       mutation_type = "random", # 突變方式
                       mutation_by_replacement = True,
                       random_mutation_min_val = 0,
                       random_mutation_max_val = mutation_max_val,

                       # 適應度函數
                       fitness_func = fitness_func,

                       num_generations = 100 # 跑幾個世代
                    )
ga_instance.run() # 執行 GA

ga_instance.plot_result() # 繪製各世代的適應度趨勢

# 取得最佳解
solution, solution_fitness, solution_idx = ga_instance.best_solution()
print("=========================================")
print("最佳解 : {solution}".format(solution = solution_map["".join(str(x) for x in solution)]))
print("最佳解的適應度 : {solution_fitness}".format(solution_fitness = solution_fitness))
print("最佳解的適應度倒數 : {solution_fitness}".format(solution_fitness = str(1/solution_fitness)))
if ga_instance.best_solution_generation != -1:
    print("最佳解落在第 {best_solution_generation} 個世代".format(best_solution_generation = ga_instance.best_solution_generation))

#顯示最佳解的Move組合    
dfResult = dfWipExcel.reset_index()
dfResult = dfResult.fillna(0)
dfResult["MOVE_UB"] = dfResult["WIP"] + dfResult["CLOSE_WIP"] #wip upper bound by op
dfSol = pd.DataFrame({'MOVE_PREDICT':solution_map["".join(str(x) for x in solution)]})
dfResult = pd.concat([dfResult, dfSol.reindex(dfResult.index)], axis=1)

dfResult = dfResult.assign(PRE_MOVE_PREDICT = 0.0)
for idx in dfResult.index: 
    if idx > 0:
        dfResult.loc[int(idx),'PRE_MOVE_PREDICT'] = dfResult.loc[int(idx)-1,'MOVE_PREDICT']

dfResult.loc[0,'PRE_MOVE_PREDICT'] = 100.0
dfResult.loc[10,'PRE_MOVE_PREDICT'] = 50.0
dfResult.loc[17,'PRE_MOVE_PREDICT'] = 0.0
dfResult.loc[26,'PRE_MOVE_PREDICT'] = 100.0
dfResult = dfResult.assign(MOVE_UB2 = dfResult['WIP'] + dfResult['PRE_MOVE_PREDICT'])


#dfResultShow = dfResult[['PROD','OP','TOOLG','WIP','CLOSE_WIP','MOVE','FCST_MOVE','MOVE_PREDICT','PRE_MOVE_PREDICT','MOVE_UB2']] 
dfResultShow = dfResult[['PROD','OP','TOOLG','WIP','CLOSE_WIP','MOVE','FCST_MOVE','MOVE_PREDICT']] 
print("==最佳解 MOVE PREDICT ==")
print(dfResultShow)

#check move total by Prod
dfProdMoveTarget = get_prod_move_target()
dfResult_validProd = dfResult.groupby(['PROD'])['MOVE_PREDICT'].sum().reset_index()
dfResult_validProd = pd.concat([dfResult_validProd, dfProdMoveTarget.reindex(dfResult_validProd.index)], axis=1)
dfResult_validProd = dfResult_validProd[['PROD','FCST_MOVE','MOVE_PREDICT']]
print("==check move total by Prod==")
print(dfResult_validProd)

#check move total by Mg
dfMgMoveTarget = get_mg_move_target()
dfResult_validMg = dfResult.groupby(['TOOLG'])['MOVE_PREDICT'].sum().reset_index()
dfResult_validMg = pd.concat([dfResult_validMg, dfMgMoveTarget.reindex(dfResult_validMg.index)], axis=1)
dfResult_validMg = dfResult_validMg[['TOOLG','FCST_MOVE','MOVE_PREDICT']]
print("==check move total by Mg==")
print(dfResult_validMg)

etime = datetime.datetime.now() 
print("處理時間 : {stime} - {etime}".format(stime = stime, etime = etime))
